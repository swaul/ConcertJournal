import SwiftUI
import SpotifyiOS

struct LoginView: View {

    @Environment(\.dependencies) var dependencies

    @State var viewModel: AuthViewModel?
    
    @State private var showPassword = false

    var body: some View {
        Group {
            if let viewModel {
                NavigationStack {
                    viewWithViewModel(viewModel: viewModel)
                }
            } else {
                Text("Laden fehlgeschlagen")
            }
        }
        .task {
            guard viewModel == nil else { return }
            viewModel = AuthViewModel(supabaseClient: dependencies.supabaseClient)
        }
    }
    
    @ViewBuilder
    func viewWithViewModel(viewModel: AuthViewModel) -> some View {
        @Bindable var viewModel = viewModel

        VStack(spacing: 16) {

            Spacer()
            VStack(alignment: .leading, spacing: 8) {
                TextField("Email", text: $viewModel.email)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.emailAddress)
                    .font(.cjBody)
                    .padding()
                    .glassEffect()
                
                ZStack {
                    if showPassword {
                        TextField("Password", text: $viewModel.password)
                            .textInputAutocapitalization(.never)
                            .font(.cjBody)
                            .padding()
                            .glassEffect()
                    } else {
                        SecureField("Password", text: $viewModel.password)
                            .font(.cjBody)
                            .padding()
                            .glassEffect()
                    }
                    
                    HStack {
                        Spacer()
                        Button {
                            withAnimation {
                                showPassword.toggle()
                            }
                        } label: {
                            showPassword ? Image(systemName: "eye") : Image(systemName: "eye.slash")
                        }
                        .contentShape(Rectangle())
                        .padding(.horizontal)
                    }
                }
            }

            if let error = viewModel.errorMessage {
                Text(error)
                    .foregroundStyle(.red)
                    .font(.cjFootnote)
            }

            HStack(spacing: 12) {
                Button {
                    Task { await viewModel.signInWithEmail() }
                } label: {
                    Text("Sign In")
                        .font(.cjBody)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(viewModel.isLoading || viewModel.email.isEmpty || viewModel.password.isEmpty)

                Button {
                    Task { await viewModel.signUpWithEmail() }
                } label: {
                    Text("Sign Up")
                        .font(.cjBody)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .disabled(viewModel.isLoading || viewModel.email.isEmpty || viewModel.password.isEmpty)
            }

            Divider().padding(.vertical, 8)

            Button {
                Task { await viewModel.signInWithSpotify() }
            } label: {
                HStack {
                    Image("Spotify")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 38)
                    Text("Mit Spotify anmelden")
                        .font(.cjBody)
                    Spacer()
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(viewModel.isLoading)
        }
        .padding()
        .navigationTitle("Login")
    }
}
