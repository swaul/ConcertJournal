//
//  EditConcertView.swift
//  concertjournal
//
//  Created by Paul Kühnel on 05.01.26.
//

import SwiftUI
import Supabase

struct ConcertEditView: View {

    @Environment(\.dismiss) private var dismiss
    @Environment(\.dependencies) private var dependencies

    @State private var title: String
    @State private var date: Date
    @State private var notes: String
    @State private var rating: Int
    @State private var venueName: String
    
    @State private var venue: Venue?
    @State private var setlistItems: [TempCeateSetlistItem]

    @State private var selectVenuePresenting = false
    @State private var editSeltistPresenting = false
    let concert: FullConcertVisit
    
    let onSave: (ConcertUpdate) -> Void

    init(concert: FullConcertVisit, onSave: @escaping (ConcertUpdate) -> Void) {
        _title = State(initialValue: concert.title ?? "")
        _date = State(initialValue: concert.date)
        _notes = State(initialValue: concert.notes ?? "")
        _rating = State(initialValue: concert.rating ?? 0)
        _venueName = State(initialValue: concert.venue?.name ?? "")
        _venue = State(initialValue: concert.venue)
        if let setlistItems = concert.setlistItems {
            let tempSetlistItems = setlistItems.map { TempCeateSetlistItem(setlistItem: $0) }
            _setlistItems = State(initialValue: tempSetlistItems)
        }
        _setlistItems = State(initialValue: [])

        self.concert = concert
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Titel", text: $title)
                    DatePicker("Datum", selection: $date, displayedComponents: .date)
                } header: {
                    Text("Konzert")
                        .font(.cjBody)
                }

                Section {
                    Button {
                        selectVenuePresenting = true
                    } label: {
                        if !venueName.isEmpty {
                            VStack(alignment: .leading) {
                                Text(venueName)
                                    .font(.cjBody)
                                if let city = venue?.city {
                                    Text(city)
                                        .font(.cjBody)
                                }
                            }
                        } else {
                            Text("Venue auswählen (optional)")
                                .font(.cjBody)
                        }
                    }
                    .buttonStyle(.plain)
                } header: {
                    Text("Location")
                        .font(.cjBody)
                }
                
                Section {
                    TextEditor(text: $notes)
                        .frame(minHeight: 120)
                        .font(.cjBody)
                } header: {
                    Text("Notizen")
                        .font(.cjBody)
                }

                Section {
                    if !setlistItems.isEmpty {
                        ForEach(setlistItems.enumerated(), id: \.element.id) { index, item in
                            makeEditSongView(index: index, song: item)
                        }
                        Button {
                            editSeltistPresenting = true
                        } label: {
                            Text("Setlist hinzufügen")
                                .font(.cjBody)
                        }
                    } else {
                        Button {
                            editSeltistPresenting = true
                        } label: {
                            Text("Setlist hinzufügen")
                                .font(.cjBody)
                        }
                    }
                } header: {
                    Text("Setlist")
                        .font(.cjBody)
                }
                .sheet(isPresented: $editSeltistPresenting) {
                    let viewModel = CreateSetlistViewModel(currentSelection: setlistItems, spotifyRepository: dependencies.spotifyRepository, setlistRepository: dependencies.setlistRepository)
                    CreateSetlistView(viewModel: viewModel) { items in
                        self.setlistItems = items
                    }
                }

                Section {
                    Stepper(value: $rating, in: 0...10) {
                        HStack {
                            Text("Rating")
                                .font(.cjBody)
                            Spacer()
                            Text("\(rating)")
                                .monospacedDigit()
                                .foregroundStyle(.secondary)
                                .font(.cjBody)
                        }
                    }
                } header: {
                    Text("Bewertung")
                        .font(.cjBody)
                }
            }
            .navigationTitle("Konzert bearbeiten")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        dismiss()
                    } label: {
                        Text("Abbrechen")
                            .font(.cjBody)
                    }
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        onSave(
                            ConcertUpdate(
                                title: title,
                                date: date.supabseDateString,
                                notes: notes,
                                venue: venue,
                                city: venue?.city,
                                rating: rating,
                                setlistItems: setlistItems
                            )
                        )
                        dismiss()
                    } label: {
                        Text("Speichern")
                            .font(.cjBody)
                    }
                }
            }
            .sheet(isPresented: $selectVenuePresenting) {
                CreateConcertSelectVenueView(isPresented: $selectVenuePresenting, onSelect: { venue in
                    self.venueName = venue.name
                    self.venue = venue
                })
            }
        }
    }

    @ViewBuilder
    func makeEditSongView(index: Int, song: TempCeateSetlistItem) -> some View {
        HStack {
            Grid(verticalSpacing: 8) {
                GridRow {
                    Text("\(index + 1).")
                        .font(.cjTitle2)
                        .frame(width: 28)
                    Text(song.title)
                        .font(.cjHeadline)
                        .lineLimit(nil)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                    GridRow {
                        Rectangle().fill(.clear)
                            .frame(width: 28, height: 1)

                        Text(song.artistNames)
                            .font(.cjBody)
                            .lineLimit(nil)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
            }
            .frame(maxWidth: .infinity)
            Image(systemName: "line.3.horizontal")
                .frame(width: 28)
        }
    }
}

struct ConcertUpdate {
    let title: String
    let date: String
    let notes: String
    let venue: Venue?
    let city: String?
    let rating: Int
    let setlistItems: [TempCeateSetlistItem]?
}
