//
//  BFFSpotifyRepository.swift
//  concertjournal
//
//  Spotify Repository mit BFF Integration
//

import Foundation
import Supabase

// MARK: - Protocol

protocol SpotifyRepositoryProtocol {
    // Search
    func searchTracks(query: String, limit: Int, offset: Int) async throws -> [SpotifySong]
    func searchArtists(query: String, limit: Int, offset: Int) async throws -> [SpotifyArtist]
    func searchPlaylists(query: String, limit: Int) async throws -> [SpotifyPlaylist]

    func getArtistTopTracks(artistId: String) async throws -> [SpotifySong]
    func getTracks(trackIds: [String]) async throws -> [SpotifySong]

    // Playlists - NEW
    func getUserPlaylists(limit: Int, token: String) async throws -> [SpotifyPlaylist]
    func getPlaylist(playlistId: String, token: String) async throws -> SpotifyPlaylistDetail
    func createPlaylistFromSetlist(concertId: String, playlistName: String, description: String?, isPublic: Bool, token: String) async throws -> CreatedPlaylist
    func importPlaylistToSetlist(concertId: String?, playlistId: String, token: String) async throws -> PlaylistImportResult
}

enum SpotifyRepositoryError: Error {
    case noProviderToken
    case noAccessToken
}

struct SpotifyPlaylist: Codable, Identifiable {
    let id: String
    let name: String
    let description: String?
    let tracks: Tracks
    let images: [SpotifyImage]?

    struct Tracks: Codable {
        let total: Int
    }
}

struct SpotifyPlaylistDetail: Codable {
    let id: String
    let name: String
    let description: String?
    let images: [SpotifyImage]?
    let tracks: [PlaylistTrack]

    struct PlaylistTrack: Codable {
        let id: String
        let name: String
        let artists: String
        let duration_ms: Int
        let album: SpotifyAlbum?
    }
}

struct CreatedPlaylist: Codable {
    let id: String
    let name: String
    let url: String
}

struct PlaylistImportResult: Codable {
    let skipped: Int
    let items: [TempCeateSetlistItem]
}

// MARK: - Request Models

struct CreatePlaylistRequest: Codable {
    let concertId: String
    let playlistName: String
    let playlistDescription: String?
    let isPublic: Bool?
}

struct ImportPlaylistRequest: Codable {
    let concertId: String?
    let playlistId: String
}

// MARK: - Backend Response Wrappers

private struct PlaylistsResponse: Codable {
    let total: Int
    let items: [SpotifyPlaylist]
}

private struct CreatePlaylistResponse: Codable {
    let success: Bool
    let playlist: CreatedPlaylist
}

private struct ImportPlaylistResponse: Codable {
    let skipped: Int
    let items: [TempCeateSetlistItem]
}

private struct SpotifyToken {
    let token: String
    let expiresAt: Date

    init(from tokenResponse: SpotifyTokenResponse) {
        self.token = tokenResponse.accessToken
        self.expiresAt = Date.now.addingTimeInterval(tokenResponse.expiresIn)
    }
}

// MARK: - BFF Repository Implementation

class BFFSpotifyRepository: SpotifyRepositoryProtocol {

    private let supabaseClient: SupabaseClientManagerProtocol
    private let client: BFFClient

    private let baseURL: String
    private let session: URLSession

    private var tokenCache: SpotifyToken

    init(client: BFFClient, supabaseClient: SupabaseClientManagerProtocol) {
        self.supabaseClient = supabaseClient
        self.client = client

        baseURL = "https://api.spotify.com/v1"
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 30
        self.session = URLSession(configuration: configuration)
        tokenCache = SpotifyToken(from: SpotifyTokenResponse(accessToken: "", expiresIn: 1))
    }

    // MARK: - AccessToken

    private func fetchAccessToken() async throws -> String {
        guard tokenCache.expiresAt < Date.now else { return tokenCache.token }

        let response: SpotifyTokenResponse = try await supabaseClient.client.functions
            .invoke("smart-worker")

        tokenCache = SpotifyToken(from: response)

        return response.accessToken
    }

    // MARK: - Search Functions

    func searchTracks(query: String, limit: Int = 20, offset: Int = 0) async throws -> [SpotifySong] {
        logDebug("Searching tracks: \(query)", category: .repository)

        let token = try await fetchAccessToken()

        struct SearchResponse: Codable {
            let tracks: [SpotifySong]
        }

        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let path = "/search?type=track?q=\(encoded)"
        let response: [SpotifySong] = try await client.requestSpotify(method: .get, url: baseURL + path, token: token)

        logSuccess("Found \(response.count) tracks", category: .repository)
        return response
    }

    func searchArtists(query: String, limit: Int = 20, offset: Int = 0) async throws -> [SpotifyArtist] {
        logDebug("Searching artists: \(query)", category: .repository)

        let token = try await fetchAccessToken()

        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let path = "/search?type=artist?q=\(encoded)"
        let response: [SpotifyArtist] = try await client.requestSpotify(method: .get, url: baseURL + path, token: token)

        logSuccess("Found \(response.count) artists", category: .repository)
        return response
    }

    func searchPlaylists(query: String, limit: Int = 20) async throws -> [SpotifyPlaylist] {
        logDebug("Searching Playlists: \(query)", category: .repository)

        let token = try await fetchAccessToken()

        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let path = "/search?type=playlist?q=\(encoded)"
        let response: [SpotifyPlaylist] = try await client.requestSpotify(method: .get, url: baseURL + path, token: token)

        logSuccess("Found \(response.count) playlists", category: .repository)
        return response
    }

    func getArtistTopTracks(artistId: String) async throws -> [SpotifySong] {
        logDebug("Getting top tracks for artist: \(artistId)", category: .repository)

        let token = try await fetchAccessToken()

        let response: [SpotifySong] = try await client.get("/spotify/artists/\(artistId)/top-tracks")

        logSuccess("Got \(response.count) top tracks", category: .repository)
        return response
    }

    func getTracks(trackIds: [String]) async throws -> [SpotifySong] {
        guard !trackIds.isEmpty else { return [] }

        logDebug("Getting \(trackIds.count) tracks", category: .repository)

        let ids = trackIds.joined(separator: ",")
        let response: [SpotifySong] = try await client.get("/spotify/tracks?ids=\(ids)")

        logSuccess("Got \(response.count) tracks", category: .repository)
        return response
    }

    // MARK: - ✅ Playlist Functions

    func getUserPlaylists(limit: Int = 50, token: String) async throws -> [SpotifyPlaylist] {
        logDebug("Getting user playlists (limit: \(limit))", category: .repository)

        let url = "https://api.spotify.com/v1/me/playlists?limit=\(limit)"
        let response: PlaylistsResponse = try await client.requestSpotify(method: .get, url: url, token: token)

        logSuccess("Got \(response.total) playlists", category: .repository)
        return response.items
    }

    func getPlaylist(playlistId: String, token: String) async throws -> SpotifyPlaylistDetail {
        logDebug("Getting playlist: \(playlistId)", category: .repository)

        let response: SpotifyPlaylistDetail = try await client.get("/spotify/playlists/\(playlistId)")

        logSuccess("Got playlist: \(response.name) with \(response.tracks.count) tracks", category: .repository)
        return response
    }

    func createPlaylistFromSetlist(
        concertId: String,
        playlistName: String,
        description: String? = nil,
        isPublic: Bool = false,
        token: String
    ) async throws -> CreatedPlaylist {
        logDebug("Creating playlist from setlist: \(concertId)", category: .repository)

        let request = CreatePlaylistRequest(
            concertId: concertId,
            playlistName: playlistName,
            playlistDescription: description,
            isPublic: isPublic
        )

        let response: CreatePlaylistResponse = try await client.post("/spotify/playlists/from-setlist",
                                                                     body: request)

        logSuccess("Playlist created: \(response.playlist.name)", category: .repository)
        return response.playlist
    }

    func importPlaylistToSetlist(
        concertId: String?,
        playlistId: String,
        token: String
    ) async throws -> PlaylistImportResult {
        logDebug("Importing playlist \(playlistId) to concert \(concertId)", category: .repository)

        let request = ImportPlaylistRequest(
            concertId: concertId,
            playlistId: playlistId
        )

        let response: ImportPlaylistResponse = try await client.post("/spotify/playlists/import",
                                                                     body: request)

        logSuccess("skipped \(response.skipped)", category: .repository)

        let imported = response.items.map { $0.title }.joined(separator: ", ")
        logSuccess("Got tracks: \(imported)")

        return PlaylistImportResult(
            skipped: response.skipped,
            items: response.items
        )
    }
}

struct SpotifyTokens {
    let providerToken: String
    let providerRefreshToken: String
}
