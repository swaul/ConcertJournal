import Foundation
import Supabase
import Combine

protocol UserSessionManagerProtocol {
    var session: Session? { get }
    var user: User? { get }
    var userId: String? { get }
    var providerToken: String? { get }

    var userSessionChanged: AnyPublisher<User?, Never> { get }

    func start(with session: Session?) async throws
    func loadUser() async throws -> User
    func refreshSpotifyProviderTokenIfNeeded() async
}

enum UserError: Error {
    case notLoggedIn
}

enum UserSessionState {
    case loggedOut
    case initializing
    case loggedIn(User)
}

@MainActor
@Observable
final class UserSessionManager: UserSessionManagerProtocol {
    
    private(set) var state: UserSessionState = .initializing
    
    var userSessionChanged: AnyPublisher<User?, Never> {
        userSessionChangedSubject.eraseToAnyPublisher()
    }
    
    let userSessionChangedSubject = PassthroughSubject<User?, Never>()
    
    private(set) var session: Session?
    private(set) var user: User?
    
    var userId: String? {
        user?.id.uuidString
    }

    var providerToken: String? {
        session?.providerToken
    }

    let client: SupabaseClient

    init(client: SupabaseClient) {
        self.client = client
    }

    /// Checks if the current session's provider token is expired and attempts a refresh for Spotify.
    func refreshSpotifyProviderTokenIfNeeded() async {
        guard session?.isExpired == true || session?.providerToken == nil else { return }

        logInfo("Attempting to refresh Spotify provider token", category: .auth)
        do {
            let newSession = try await client.auth.refreshSession()
            try await update(session: newSession)

            logSuccess("Spotify provider token refreshed", category: .auth)
        } catch {
            logError("Failed to refresh Spotify provider token", error: error, category: .auth)
        }
    }

    func start(with session: Session? = nil) async throws {
        logInfo("UserSessionManager.start()", category: .auth)
        state = .initializing
        
        // Try to get current session if available
        let currentSession: Session?
        if let session {
            currentSession = session
        } else {
            do {
                currentSession = try? await client.auth.session
            }
        }

        if currentSession?.user.identities?.contains(where: { $0.provider == "spotify" }) == true, currentSession?.providerToken == nil {
            let provider: Provider = .spotify
            let redirectTo = URL(string: "concertjournal://auth-callback")!
            let scopes = "user-read-email playlist-read-private playlist-read-collaborative playlist-modify-public playlist-modify-private user-library-read"
            
            let newSession = try await client.auth.signInWithOAuth(provider: provider, redirectTo: redirectTo, scopes: scopes)
            guard newSession.providerToken != nil else { return }
            try await start(with: newSession)
        }

        // Update to current session (may be nil)
        try await update(session: currentSession)

        // Start listening to auth state changes in a detached Task so start() can return
        Task { [weak self] in
            guard let self else { return }
            for await event in self.client.auth.authStateChanges {
                await MainActor.run {
                    logInfo("Auth state change: \(event.event)", category: .auth)
                }
                do {
                    try await self.update(session: event.session)
                } catch {
                    logError("Failed to update session after auth change", error: error, category: .auth)
                }
            }
        }
    }
    
    private func update(session: Session?) async throws {
        self.session = session
        self.user = session?.user

        if let user = session?.user {
            state = .loggedIn(user)
        } else {
            state = .loggedOut
        }

        userSessionChangedSubject.send(self.user)
    }
    
    func loadUser() async throws -> User {
        if let user = self.user { return user }
        do {
            let user = try await client.auth.user()
            self.user = user
            state = .loggedIn(user)
            userSessionChangedSubject.send(user)
            return user
        } catch {
            state = .loggedOut
            throw UserError.notLoggedIn
        }
    }
}

