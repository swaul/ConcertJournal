//
//  PhotoRepository & StorageService
//
//  Zeigt wie Image Upload ins Repository Pattern passt
//

import UIKit
import Foundation
import Supabase

protocol StorageServiceProtocol {
    func uploadImage(_ image: UIImage, to bucket: String, path: String) async throws -> URL
    func deleteImage(from bucket: String, path: String) async throws
    func getPublicURL(bucket: String, path: String) throws -> URL
}

class StorageService: StorageServiceProtocol {

    private let supabaseClient: SupabaseClientManager

    init(supabaseClient: SupabaseClientManager) {
        self.supabaseClient = supabaseClient
    }

    func uploadImage(_ image: UIImage, to bucket: String, path: String) async throws -> URL {
        guard let data = image.jpegData(compressionQuality: 0.8) else {
            throw StorageError.compressionFailed
        }

        try await supabaseClient.client.storage
            .from(bucket)
            .upload(
                path,
                data: data,
                options: FileOptions(
                    contentType: "image/jpeg",
                    upsert: false
                )
            )

        return try getPublicURL(bucket: bucket, path: path)
    }

    func deleteImage(from bucket: String, path: String) async throws {
        try await supabaseClient.client.storage
            .from(bucket)
            .remove(paths: [path])
    }

    func getPublicURL(bucket: String, path: String) throws -> URL {
        return try supabaseClient.client.storage
            .from(bucket)
            .getPublicURL(path: path)
    }
}

enum StorageError: Error, LocalizedError {
    case compressionFailed
    case uploadFailed
    case deleteFailed

    var errorDescription: String? {
        switch self {
        case .compressionFailed:
            return "Bild konnte nicht komprimiert werden"
        case .uploadFailed:
            return "Upload fehlgeschlagen"
        case .deleteFailed:
            return "Löschen fehlgeschlagen"
        }
    }
}

// ============================================================================
// PHOTO MODEL
// ============================================================================

struct ConcertPhoto: Codable, Identifiable {
    var id: String {
        publicUrl
    }

    let concertVisitId: String
    let userId: String
    let storagePath: String
    let publicUrl: String

    enum CodingKeys: String, CodingKey {
        case concertVisitId = "concert_visit_id"
        case userId = "user_id"
        case storagePath = "storage_path"
        case publicUrl = "public_url"
    }

}

// ============================================================================
// PHOTO REPOSITORY - Nutzt Storage Service
// ============================================================================


// ============================================================================
// MOCK REPOSITORIES FÜR TESTS
// ============================================================================

class MockStorageService: StorageServiceProtocol {

    var shouldFail = false
    var uploadedImages: [(image: UIImage, bucket: String, path: String)] = []

    func uploadImage(_ image: UIImage, to bucket: String, path: String) async throws -> URL {
        if shouldFail {
            throw StorageError.uploadFailed
        }

        uploadedImages.append((image, bucket, path))
        return URL(string: "https://example.com/\(path)")!
    }

    func deleteImage(from bucket: String, path: String) async throws {
        uploadedImages.removeAll { $0.path == path }
    }

    func getPublicURL(bucket: String, path: String) throws -> URL {
        return URL(string: "https://example.com/\(path)")!
    }
}

class MockPhotoRepository: PhotoRepositoryProtocol {

    var mockPhotos: [ConcertPhoto] = []

    func uploadPhoto(image: UIImage, concertVisitId: String, userId: String) async throws -> ConcertPhoto {
        let photo = ConcertPhoto(
            concertVisitId: concertVisitId,
            userId: userId,
            storagePath: "mock/path.jpg",
            publicUrl: "https://example.com/mock.jpg",
        )
        mockPhotos.append(photo)
        return photo
    }

    func fetchPhotos(for concertVisitId: String) async throws -> [ConcertPhoto] {
        return mockPhotos.filter { $0.concertVisitId == concertVisitId }
    }

    func deletePhoto(id: String, storagePath: String) async throws {
        mockPhotos.removeAll { $0.id == id }
    }
}
//
//// ============================================================================
//// VERWENDUNG IM VIEWMODEL
//// ============================================================================
//
//@Observable
//class ConcertDetailViewModel {
//
//    var photos: [ConcertPhoto] = []
//    var isUploadingPhotos = false
//    var uploadProgress: Double = 0
//
//    private let photoRepository: PhotoRepositoryProtocol
//    private let concertId: String
//    private let userId: String
//
//    init(photoRepository: PhotoRepositoryProtocol, concertId: String, userId: String) {
//        self.photoRepository = photoRepository
//        self.concertId = concertId
//        self.userId = userId
//    }
//
//    // ✅ Load Photos
//    func loadPhotos() async {
//        do {
//            photos = try await photoRepository.fetchPhotos(for: concertId)
//        } catch {
//            print("Error loading photos: \(error)")
//        }
//    }
//
//    // ✅ Upload Multiple Photos
//    func uploadPhotos(_ images: [UIImage]) async {
//        isUploadingPhotos = true
//        uploadProgress = 0
//
//        for (index, image) in images.enumerated() {
//            do {
//                let photo = try await photoRepository.uploadPhoto(
//                    image: image,
//                    concertVisitId: concertId,
//                    userId: userId
//                )
//
//                photos.append(photo)
//                uploadProgress = Double(index + 1) / Double(images.count)
//
//            } catch {
//                print("Failed to upload photo: \(error)")
//            }
//        }
//
//        isUploadingPhotos = false
//    }
//
//    // ✅ Delete Photo
//    func deletePhoto(_ photo: ConcertPhoto) async {
//        do {
//            try await photoRepository.deletePhoto(
//                id: photo.id,
//                storagePath: photo.storagePath
//            )
//
//            photos.removeAll { $0.id == photo.id }
//
//        } catch {
//            print("Failed to delete photo: \(error)")
//        }
//    }
//}
//
//// ============================================================================
//// VIEW BEISPIEL
//// ============================================================================
//
//struct ConcertPhotosView: View {
//
//    @Environment(\.dependencies) private var dependencies
//    @State private var viewModel: ConcertDetailViewModel?
//    @State private var selectedImages: [UIImage] = []
//    @State private var showImagePicker = false
//
//    let concertId: String
//
//    var body: some View {
//        ScrollView {
//            if let viewModel {
//                LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) {
//                    ForEach(viewModel.photos) { photo in
//                        AsyncImage(url: URL(string: photo.publicUrl)) { image in
//                            image
//                                .resizable()
//                                .aspectRatio(contentMode: .fill)
//                        } placeholder: {
//                            Color.gray
//                        }
//                        .frame(width: 100, height: 100)
//                        .clipShape(RoundedRectangle(cornerRadius: 8))
//                        .contextMenu {
//                            Button(role: .destructive) {
//                                Task {
//                                    await viewModel.deletePhoto(photo)
//                                }
//                            } label: {
//                                Label("Löschen", systemImage: "trash")
//                            }
//                        }
//                    }
//                }
//
//                if viewModel.isUploadingPhotos {
//                    ProgressView(value: viewModel.uploadProgress) {
//                        Text("Hochladen...")
//                    }
//                }
//            }
//        }
//        .toolbar {
//            Button {
//                showImagePicker = true
//            } label: {
//                Image(systemName: "plus")
//            }
//        }
//        .sheet(isPresented: $showImagePicker) {
//            // PhotosPicker hier
//        }
//        .task {
//            if viewModel == nil {
//                guard let userId = dependencies.supabaseClient.currentUserId?.uuidString else {
//                    return
//                }
//
//                viewModel = ConcertDetailViewModel(
//                    photoRepository: dependencies.photoRepository,
//                    concertId: concertId,
//                    userId: userId
//                )
//
//                await viewModel?.loadPhotos()
//            }
//        }
//    }
//}
//
//// ============================================================================
//// DEPENDENCY CONTAINER UPDATE
//// ============================================================================
//
///*
// class DependencyContainer {
//
// // ... andere Dependencies
//
// let storageService: StorageServiceProtocol
// let photoRepository: PhotoRepositoryProtocol
//
// init() {
// self.supabaseClient = SupabaseClientManager()
//
// // Storage Service
// self.storageService = StorageService(
// supabaseClient: supabaseClient
// )
//
// // Photo Repository nutzt Storage Service
// self.photoRepository = PhotoRepository(
// supabaseClient: supabaseClient,
// storageService: storageService
// )
//
// // ... andere Repositories
// }
// }
// */
//
//// ============================================================================
//// ZUSAMMENFASSUNG
//// ============================================================================
//
///*
// IMAGE UPLOAD ARCHITEKTUR:
//
// View
// ↓
// ViewModel (uploadPhotos)
// ↓
// PhotoRepository
// ├── StorageService → Upload zu Supabase Storage
// └── SupabaseClient → Speichere Metadaten in DB
//
// VORTEILE:
//
// 1. SEPARATION OF CONCERNS:
// - StorageService: Nur Storage-Operationen
// - PhotoRepository: Koordiniert Storage + DB
// - ViewModel: UI Logic
//
// 2. WIEDERVERWENDBAR:
// - StorageService kann für User Avatars, etc. genutzt werden
// - PhotoRepository ist spezifisch für Concert Photos
//
// 3. TESTBAR:
// - MockStorageService für Tests
// - MockPhotoRepository für UI Tests
//
// 4. TYPE SAFE:
// - Klare Interfaces
// - Keine Magic Strings
//
// 5. ERROR HANDLING:
// - Zentral im Repository
// - Custom Errors
//
// MIGRATION VON ALTEM CODE:
//
// ❌ VORHER:
// let imageUploader = ImageUploader()
// try await imageUploader.uploadPhoto(image: image, concertVisitId: id)
//
// ✅ NACHHER:
// let photo = try await photoRepository.uploadPhoto(
// image: image,
// concertVisitId: id,
// userId: userId
// )
// */
