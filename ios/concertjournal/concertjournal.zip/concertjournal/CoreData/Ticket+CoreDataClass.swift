//
//  Ticket+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias TicketCoreDataClassSet = NSSet

@objc(Ticket)
public class Ticket: NSManagedObject {

}
