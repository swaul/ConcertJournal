//
//  Concert+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias ConcertCoreDataClassSet = NSSet

@objc(Concert)
public class Concert: NSManagedObject {

}
