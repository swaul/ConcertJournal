//
//  SyncLog+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias SyncLogCoreDataClassSet = NSSet

@objc(SyncLog)
public class SyncLog: NSManagedObject {

}
