//
//  SetlistItem+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias SetlistItemCoreDataClassSet = NSSet

@objc(SetlistItem)
public class SetlistItem: NSManagedObject {

}
