//
//  Artist+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias ArtistCoreDataClassSet = NSSet

@objc(Artist)
public class Artist: NSManagedObject {

}
