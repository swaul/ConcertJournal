//
//  Tour+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 24.02.26.
//
//

public import Foundation
public import CoreData

public typealias TourCoreDataClassSet = NSSet

@objc(Tour)
public class Tour: NSManagedObject {

}
