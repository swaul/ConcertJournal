//
//  Travel+CoreDataClass.swift
//  concertjournal
//
//  Created by Paul Kühnel on 16.02.26.
//
//

public import Foundation
public import CoreData

public typealias TravelCoreDataClassSet = NSSet

@objc(Travel)
public class Travel: NSManagedObject {

}
