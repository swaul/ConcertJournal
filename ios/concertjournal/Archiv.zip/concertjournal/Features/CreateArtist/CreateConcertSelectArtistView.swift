//
//  CreateConcertSelectArtistView.swift
//  concertjournal
//
//  Created by Paul Kühnel on 23.12.25.
//

import SwiftUI

struct CreateConcertSelectArtistView: View {

    @Environment(\.dependencies) private var dependencies

    init(isPresented: Binding<Bool>, didSelectArtist: @escaping (ArtistDTO) -> Void) {
        self.didSelectArtist = didSelectArtist
        self._isPresented = isPresented
    }

    @State var viewModel: CreateConcertSelectArtistViewModel? = nil

    @Binding var isPresented: Bool

    var didSelectArtist: (ArtistDTO) -> Void?

    @State var artistName: String = ""
    @State var hasText: Bool = false

    @State var didSearch: Bool = false

    @State var selectedArtist: String? = nil

    @FocusState var textFieldFocused: Bool
    
    @State var textFieldFocusedAnimated: Bool = false
    @State var isSearchingAnimated: Bool = false

    @Namespace var selection

    var body: some View {
        NavigationStack {
            Group {
                if let viewModel {
                    viewWithViewModel(viewModel: viewModel)
                } else {
                    LoadingView()
                }
            }
            .background {
                Color.background.ignoresSafeArea()
            }
            .navigationTitle("Select an Artist")
            .task {
                viewModel = CreateConcertSelectArtistViewModel(spotifyRepository: dependencies.spotifyRepository,
                                                               offlineConcertRepository: dependencies.offlineConcertRepository)
            }
        }
    }

    @ViewBuilder
    func viewWithViewModel(viewModel: CreateConcertSelectArtistViewModel) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                if isSearchingAnimated {
                    SearchingView(searchContent: "Künstler")
                } else if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .font(.cjBody)
                        .padding()
                } else if !didSearch {
                    ForEach(viewModel.currentArtists) { artist in
                        Button {
                            HapticManager.shared.buttonTap()
                            selectedArtist = artist.id.uuidString
                        } label: {
                            makeKnownArtistView(artist: artist)
                                .contentShape(.rect)
                        }
                        .buttonStyle(.plain)
                    }
                } else {
                    ForEach(viewModel.artistsResponse) { artist in
                        Button {
                            HapticManager.shared.buttonTap()
                            selectedArtist = artist.id
                        } label: {
                            makeArtistView(artist: artist)
                                .contentShape(.rect)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding()
        }
        .scrollDismissesKeyboard(.interactively)
        .onChange(of: textFieldFocused, { _, newValue in
            withAnimation(.bouncy) {
                textFieldFocusedAnimated = newValue
            }
        })
        .onChange(of: viewModel.isSearching, { _, newValue in
            withAnimation {
                isSearchingAnimated = newValue
            }
        })
        .toolbar {
            if selectedArtist != nil {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        HapticManager.shared.buttonTap()
                        selectArtist(viewModel: viewModel)
                    } label: {
                        Text(TextKey.save.localized)
                            .font(.cjBody)
                    }
                }
            }
        }
        .safeAreaInset(edge: .bottom) {
            HStack {
                TextField(text: $artistName) {
                    Text(TextKey.selectArtist.localized)
                        .font(.cjBody)
                }
                .focused($textFieldFocused)
                .submitLabel(.search)
                .onSubmit {
                    HapticManager.shared.navigationTap()
                    viewModel.searchArtists(with: artistName)
                    didSearch = true
                    textFieldFocused = false
                }
                .onChange(of: artistName) { _, newValue in
                    withAnimation {
                        hasText = !newValue.isEmpty
                    }
                }
                .padding()
                .glassEffect()
                
                if textFieldFocusedAnimated {
                    Button {
                        HapticManager.shared.buttonTap()
                        textFieldFocused = false
                    } label: {
                        Text(TextKey.done.localized)
                            .font(.cjBody)
                    }
                    .buttonStyle(.glass)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                }

                if hasText {
                    Button {
                        HapticManager.shared.buttonTap()
                        viewModel.searchArtists(with: artistName)
                        textFieldFocused = false
                        didSearch = true
                    } label: {
                        Text("Search")
                            .font(.cjBody)
                    }
                    .buttonStyle(.glassProminent)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
    }

    func makeArtistView(artist: SpotifyArtist) -> some View {
        HStack {
            Group {
                if let url = artist.firstImageURL {
                    AsyncImage(url: url) { result in
                        result.image?
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80)
                    }
                } else {
                    ZStack {
                        Rectangle()
                            .frame(width: 80, height: 80)
                            .background { Color.gray }
                        Image(systemName: "note")
                            .frame(width: 32)
                            .foregroundStyle(.white)
                    }
                }
            }
            .clipShape(.circle)
            .frame(width: 80, height: 80)
            .padding()

            VStack(alignment: .leading, spacing: 8) {
                Text(artist.name)
                    .font(.cjBody)
                    .bold()
                Text("Follower: \(artist.followers?.total ?? 0)")
                    .font(.cjBody)
            }
            .padding(.vertical)
            .padding(.trailing)

            Spacer()
        }
        .selectedGlass(selected: selectedArtist == artist.id)
    }

    func makeKnownArtistView(artist: Artist) -> some View {
        HStack {
            Group {
                if let url = artist.imageUrl {
                    AsyncImage(url: URL(string: url)) { result in
                        result.image?
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 80)
                    }
                } else {
                    ZStack {
                        Rectangle()
                            .frame(width: 80, height: 80)
                            .background { Color.gray }
                        Image(systemName: "note")
                            .frame(width: 32)
                            .foregroundStyle(.white)
                    }
                }
            }
            .clipShape(.circle)
            .frame(width: 80, height: 80)
            .padding()

            Text(artist.name)
                .font(.cjBody)
                .bold()
                .padding(.vertical)
                .padding(.trailing)

            Spacer()
        }
        .selectedGlass(selected: selectedArtist == artist.id.uuidString)
    }


    private func selectArtist(viewModel: CreateConcertSelectArtistViewModel) {
        if let artist = viewModel.artistsResponse.first(where: { $0.id == selectedArtist }) {
            didSelectArtist(ArtistDTO(artist: artist))
            isPresented = false
        } else if let artist = viewModel.currentArtists.first(where: { $0.id.uuidString == selectedArtist }) {
            didSelectArtist(artist.toDTO())
            isPresented = false
        }
    }
}
